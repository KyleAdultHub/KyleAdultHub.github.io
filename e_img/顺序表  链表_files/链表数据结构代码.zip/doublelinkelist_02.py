# coding=utf-8
class Node(object):
    """节点类"""
    def __init__(self, item):
        # 初始化变量item，记录数据内容
        self.item = item
        # 初始化变量next，记录下一个节点
        self.next = None
        # 初始化变量pre，记录前一个节点
        self.pre = None

class DoubleLinkList(object):

    def __init__(self):
        """记录头节点,所有操作都要从头节点开始"""
        self.__head = None

    def is_empty(self):
        """判断链表是否为空,即判断头节点是不是none值"""
        return self.__head is None

    def length(self):
        """获取链表的长度"""
        cur = self.__head
        count = 0
        while cur is not None:
            count += 1
            cur = cur.next
        return count

    def travel(self):
        """遍历整个列表"""

        cur = self.__head
        while cur is not None:
            print(cur.item, end=' ')
            cur = cur.next
        print(' ')

    def add(self, item):
        """向链表的头部添加元素"""
        node = Node(item)
        if self.is_empty():
            self.__head = node
            return

        node.next = self.__head
        self.__head.pre = node
        self.__head = node

    def append(self, item):
        """向链表尾部添加数据"""
        if self.is_empty():
            self.add(item)
            return
        cur = self.__head
        while cur.next is not None:
            cur = cur.next
        node = Node(item)
        cur.next = node
        node.pre = cur

    def insert(self, pos, item):
        """指定位置添加元素"""
        if pos  <= 0:
            self.add(item)

        elif pos > (self.length() - 1):
            self.append(item)
        else:
            index = 0
            cur = self.__head
            while index < pos - 1:
                index += 1
                cur = cur.next
            node = Node(item)
            node.next = cur.next
            cur.next.pre = node
            cur.next = node
            node.pre = cur

    def remove(self, item):
        """删除节点"""
        cur = self.__head
        while cur is not None:
            if cur.item == item:
                if cur.pre is None:
                    self.__head = cur.next
                else:
                    cur.pre.next = cur.next
                    if cur.next is not None:
                        cur.next.pre = cur.pre
                return

            cur = cur.next


    def search(self, item):
        """查看节点是否存在"""
        cur = self.__head
        while cur is not None:
            if cur.item == item:
                return True
            cur = cur.next

        return False

if __name__ == '__main__':
    sll = DoubleLinkList()
    print(sll.is_empty())
    print(sll.length())
    sll.add(1)
    sll.add(2)
    sll.add(3)
    print(sll.length())
    print(sll.is_empty())
    sll.travel()
    sll.add(4)
    sll.travel()
    print(sll.length())
    sll.append(5)
    sll.travel()

    sll.insert(-100, 6)
    sll.travel()
    sll.insert(100, 7)
    sll.travel()
    sll.insert(2, 8)
    sll.travel()

    sll.remove(3)
    sll.travel()
    sll.remove(6)
    sll.travel()
    print(sll.search(2))
    print(sll.search(6))





