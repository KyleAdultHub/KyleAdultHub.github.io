# coding=utf-8
class Node(object):
    """节点类"""
    def __init__(self, item):
        # 初始化变量item，记录数据内容
        self.item = item
        # 初始化变量next，记录下一个节点
        self.next = None


class SingleCycLinkList(object):
    """单循环链表类"""

    def __init__(self):
        """记录头节点，所有的操作都需要从头节点开始"""
        self.__head = None

    def is_empty(self):
        """链表是否为空"""
        # 判断头节点是否为空
        return self.__head is None

    def length(self):
        """链表长度"""
        if self.is_empty():
            return 0
        # 需要从头遍历
        # 定义计数变量，每遍历一个节点，计数+1
        cur = self.__head
        count = 1
        while cur.next is not self.__head:
            count += 1
            cur = cur.next
        return count

    def travel(self):
        """遍历整个链表"""
        if self.is_empty():
            return
        # 从首节点开始
        # 定义游标变量，一次往下一个移动
        cur = self.__head
        print(cur.item, end=" ")
        while cur.next is not self.__head:
            # 游标移动到下一个节点
            cur = cur.next
            # 输出当前节点内容
            print(cur.item, end=" ")
        print()

    def add(self,item):
        """链表头部添加元素"""
        # 创建节点对象
        node = Node(item)
        if self.is_empty():
            self.__head = node
            node.next = self.__head
            return

        # 遍历，找到尾节点
        cur = self.__head
        while cur.next is not self.__head:
            # 游标移动到下一个节点
            cur = cur.next
        # 循环结束是，cur指向的是尾节点
        node.next = self.__head
        self.__head = node
        cur.next = self.__head

    def append(self,item):
        """链表尾部添加元素"""
        # 判断当前链表是否为空
        if self.is_empty():
            self.add(item)
            return
        # 遍历，找到尾部节点
        cur = self.__head
        while cur.next is not self.__head:
            # 游标移动到下一个节点
            cur = cur.next
        # 循环结束后，cur指向的就是尾节点
        node = Node(item)
        cur.next = node
        node.next = self.__head

    def insert(self,pos, item):
        """指定位置添加元素"""
        # 保证代码的健壮性，判断传入的pos
        # 如果pos小于0，插入到头位置
        if pos <= 0:
            self.add(item)
        # 如果pos大于我的长度-1，追加到尾部
        elif pos > (self.length() - 1):
            self.append(item)
        else:
            # 插入到中间的位置
            # 找到pos的前一个位置的节点
            index = 0
            cur = self.__head
            while index < pos - 1:
                index += 1
                cur = cur.next
            # 循环结束后，cur指向的就是pos的前一个节点
            node = Node(item)
            node.next = cur.next
            cur.next = node

    def remove(self,item):
        """删除节点"""
        if self.is_empty():
            return
        # 遍历，找到要删除的节点
        cur = self.__head
        # 定义pre记录当前节点的前一个节点
        pre = None
        while cur.next is not self.__head:
            # 判断当前节点是否是要删除的节点
            if cur.item == item:
                # 如果pre为None，证明要删除的是头节点
                if pre is None:
                    # 先找到尾节点
                    temp = self.__head
                    while temp.next is not self.__head:
                        temp = temp.next
                    # 循环结束后，temp指向的是尾节点
                    self.__head = cur.next
                    temp.next = self.__head
                else:
                    pre.next = cur.next

                # 删除了一个节点后，是否需要继续遍历
                return

            pre = cur
            # 游标移动到下一个节点
            cur = cur.next
        # 循环内只能判断除了尾节点的元素
        if cur.item == item:
            # 如果pre为空，只有一个节点，且删除的就是这个节点
            if pre is None:
                self.__head = None
            else:
                # 此时删除的是尾节点
                pre.next = self.__head

    def search(self,item):
        """查找节点是否存在"""
        if self.is_empty():
            return False
        cur = self.__head
        if cur.item == item:
            return True
        while cur.next is not self.__head:
            cur = cur.next
            if cur.item == item:
                return True
        return False


if __name__ == '__main__':
    sll = SingleCycLinkList()
    print(sll.is_empty())
    print(sll.length())
    sll.add(1)
    sll.add(2)
    sll.add(3)
    print(sll.length())
    print(sll.is_empty())
    sll.travel()
    sll.add(4)
    sll.travel()
    print(sll.length())
    sll.append(5)
    sll.travel()

    sll.insert(-100, 6)
    sll.travel()
    sll.insert(100, 7)
    sll.travel()
    sll.insert(2, 8)
    sll.travel()

    sll.remove(3)
    sll.travel()
    sll.remove(6)
    sll.travel()
    print(sll.search(2))
    print(sll.search(6))
