# coding=utf-8
class Node(object):
    """定义节点类,是存储数据的基本单元"""

    def __init__(self, item):
        # 初始化变量的item,记录数据的内容
        self.item = item
        # 初始化next的指向内容,记录下一个节点的位置
        self.next = None


class SingleLinkList(object):
    """定义单项链表类"""

    def __init__(self):
        """记录头节点,头节点是所有操作的起始位置"""
        self.__head = None

    def is_empty(self):
        """判断链表是否为空的方法,直接判断头节点是否为空就可以"""
        return self.__head is None

    def length(self):
        """获取链表的长度方法,从头遍历,每遍历一个节点将长度的计数加一"""
        cur = self.__head
        count = 0
        while cur is not None:
            cur = cur.next
            count += 1
        return count

    def travel(self):
        """遍历链表,从首节点开始,定义游标变量,通过移动游标来获取每一个节点对象"""
        cur = self.__head
        while cur is not None:
            print(cur.item, end='  ')
            cur = cur.next
        print(' ')

    def add(self, item):
        """向链表头部添加元素,向头部添加节点实例,并设置加点类的next属性"""
        node = Node(item)
        node.next = self.__head
        self.__head = node

    def append(self, item):
        """链表尾部添加数据,向末尾添加节点实例,并设置之前末节点的next属性,需要判断情况"""
        # 如果当前列表为空,那么和向头部添加数据的方法一样
        if self.is_empty():
            self.add(item)
            return

        # 找到最后一个节点,并修改最后一个节点的next属性
        cur = self.__head
        while cur.next is not None:
            cur = cur.next

        node = Node(item)
        cur.next = node

    def insert(self, pos, item):
        """在制定位置添加元素,先要从头开始便利找到对应位置前一个位置,将next执行改变"""
        if pos <= 0:
            self.add(item)
        elif pos > (self.length() - 1):
            self.append(item)

        else:
            cur = self.__head
            index = 0
            while index < pos - 1:
                cur = cur.next
                index += 1
            node = Node(item)
            node.next = cur.next
            cur.next = node

    def remove(self, item):
        """删除节点, 遍历找到要删除的节点的前一个节点,修改其指向"""
        cur = self.__head
        pre = None

        while cur is not None:
            if cur.item == item:
                if pre is None:
                    self.__head = cur.next
                else:
                    pre.next = cur.next
                break
            pre = cur
            cur = cur.next

    def search(self, item):
        """查找节点是否存在"""
        cur = self.__head
        while cur is not None:
            if cur.item == item:
                return True
            cur = cur.next
        return False

if __name__ == '__main__':
    sll = SingleLinkList()
    print(sll.is_empty())
    print(sll.length())
    sll.add(1)
    sll.add(2)
    sll.add(3)
    print(sll.length())
    print(sll.is_empty())
    sll.travel()
    sll.add(4)
    sll.travel()
    print(sll.length())
    sll.append(5)
    sll.travel()

    sll.insert(-100, 6)
    sll.travel()
    sll.insert(100, 7)
    sll.travel()
    sll.insert(2, 8)
    sll.travel()

    sll.remove(3)
    sll.travel()
    sll.remove(6)
    sll.travel()
    print(sll.search(2))
    print(sll.search(6))